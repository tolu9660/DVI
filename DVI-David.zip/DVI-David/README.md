# Juego simple con Phaser

Este juego ha sido desarrollado por Carlos León Aznar. En este repositorio contiene una reorganización del código y de los assets usados para su desarrollo por Guillermo Jiménez
